#ifndef __GPIO_H_
#define __GPIO_H_
#include "stm32f10x.h"

void GpioInit(void);

#endif
